export interface Member{
    id?:number;
    name: string;
    lastName:string;
    photo:string;
    link:string;
    phone: string;
    role:string;
}